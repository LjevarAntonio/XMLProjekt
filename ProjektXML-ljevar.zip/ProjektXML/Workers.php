<!DOCTYPE html>
<html>
<head>
    <meta name="autor" content="Antonio Ljevar">
    <meta charset="utf-8">
    <title>Workers</title>
    <link rel="stylesheet" type="text/css" href="styleIndex.css">
<style>
::-webkit-scrollbar{
    width: 10px;
}
::-webkit-scrollbar-track{
    background: #cccccc;
    border-radius: 5px;
    margin: 5px 0px;

}
::-webkit-scrollbar-thumb{
    background: #003c41;
    border-radius: 5px;
    border: 2px #cccccc solid;
}
::-webkit-scrollbar-thumb:hover{
    background: #002326;
}


</style>

</head>
<body>
    <header>
        <div class="centarHead">
            <a href="index.html">
                <img src="imgs/Cam_Logo.png" id="logo" alt=""  width="80px" height="51px">
            </a>

            <div id="dropdown">
                <span id="meni">MENU <img id="Strelica" src="angle-down.svg" alt=""></span>
                <div id="dropcontent">
                    <div class="divLinka"><a href="" class="linkDrop">Workers</a></div>
                    <div class="divLinka"><a href="" class="linkDrop">About us</a></div>
                    
                </div>
            </div>
        </div>
    </header>

    <main><div id="WWD">
        <h2 id="WWDnaslov">Our Workers</h2>
        <p class="Paragrafi">Below, you are able to explore our workers list.
             If you see anyone you would like to employ or work with, feel free to contact them.
        </p>
        <div class="DivS">
        <?php 


            $ZaposlenciInfo = simplexml_load_file("ZaposleniciInfo.xml") or 
            die("Error: Nije uspostavljena veza"); 
            foreach ($ZaposlenciInfo->children() as $info) { 
                echo "<div style='margin-top:50px;text-align:center;'>";
                echo "<h1 style='text-align: center;'>", $info->ime . "</h1><br><br>  ";
                echo "<div class='zaposlenikDivUnutarnji'>";
                echo "<h3>", $info->struka . "</h3><br><br>  "; 
                echo "Phone number: ", $info->broj . "<br>  "; 
                echo "Email: ", $info->email . "<br><br> "; 
                echo "<br>"; 
                echo "</div>";
                echo "</div>";
            } 
        ?> 
        <a href="#">
        <button width="100px" value="Learn More!"></button>
        </a>
        </div>
    </main>
    <footer>
        <h6>Antonio Ljevar</h6><br><h6>0246094394</h6> 

        
    </footer>
</body>

</html>